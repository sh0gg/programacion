package ud1.api;

import java.time.LocalTime;

public class HoraLocal {
    public static void main(String[] args) {
        System.out.println("La hora del sistema es: " + LocalTime.now());
    }
}
