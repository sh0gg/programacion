package ud1.identificadores;

public class Constantes {
    public static void main(String[] args) {
        /*
         * Número de alumnos matriculados en el módulo de Programación (32 según el listado del aula virtual)
            Número total de sesiones del módulo de Programación en el curso lectivo.
            Número de sesiones semanales del módulo de Programación.
            Número de meses del año.
         */
        final byte NUM_ALUMNOS_PROGRAMACION = 32;

        System.out.println("Número de alumnos/as: " + NUM_ALUMNOS_PROGRAMACION);
        

    }
}
