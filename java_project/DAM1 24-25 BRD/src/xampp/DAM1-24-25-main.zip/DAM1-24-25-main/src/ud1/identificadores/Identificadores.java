package ud1.identificadores;

/**
 * identificadores
 */
public class Identificadores {
    
    public static void main(String[] args) {
        
        String numeroDeTelefono = "+34666666666";  
        double totalVentas = 3050.45;   // importe vendido
        final String miNombre = "Óscar";
        boolean young4ever = true; // 4everYoung non sería un identificador válido
        byte _variable = 1;
        //...

        System.out.println(numeroDeTelefono);
        System.out.println(totalVentas);
        System.out.println(miNombre);
        System.out.println(young4ever);
        System.out.println(_variable);


    }
    
}