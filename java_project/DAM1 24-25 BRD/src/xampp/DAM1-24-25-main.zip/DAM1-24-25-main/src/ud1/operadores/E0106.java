package ud1.operadores;

public class E0106 {
    public static void main(String[] args) {
        int nota1 = 3;
        int nota2 = 8;

        double media = (nota1 + nota2) / 2.0;

        System.out.println("Media: " + media);
    }
}
