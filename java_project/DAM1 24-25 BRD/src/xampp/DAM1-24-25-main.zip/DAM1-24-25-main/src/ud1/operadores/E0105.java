package ud1.operadores;

public class E0105 {
    public static void main(String[] args) {
        short x = 32767;

        x++;

        System.out.println(x);

        x--;

        System.out.println(x);

    }
}
