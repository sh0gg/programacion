package ud2.ejemplos;

// Programa que muestra los números del 10 al 1
public class EjemploFor2 {
    public static void main(String[] args) {
        for (int i = 10; i > 0; i--) {    //inicio del for                                                        
            System.out.print(i + " ");
        }  //fin del for
        System.out.println("\nFin programa");                                                                     
    }
}
