package ud2.ejemplos;

public class EjemploDoWhile3 {
    public static void main(String[] args) {
        int i = 0;
        do { // inicio del do .. while
            System.out.print(i + " ");
            i++;
        } while (i < 10); // fin del do .. while
        System.out.println("\nFin programa");
    }
}
