public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Ola Mundo!! \n Benvid@ ao repositorio de DAM1 do curso 24-25");
    }
}
