package ud1.ejercicios.parejas;

import java.util.Scanner;

public class RecetasIngredientes {

    public static void main(String[] args) {
       
        // Driver: David Besada Ramilo
        // Copilot: Carlos de la Torre Aboal
        
        Scanner scanner = new Scanner(System.in);

        System.out.print("¿Cómo hacer una compota de manzana?");
        System.out.print("=====================================");
        System.out.print("=====================================");
        System.out.print("Pincha aquí para ir a la web de la receta https://www.recetasderechupete.com/compota-de-manzana-casera/12509/");
        System.out.print("¡Esta receta es para cuatro personas!");
    }
}
