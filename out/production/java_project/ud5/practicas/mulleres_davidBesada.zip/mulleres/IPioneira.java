package ud5.practicas.mulleres;

public interface IPioneira {
    public abstract String getDescubrimentoOuAporte();
}
