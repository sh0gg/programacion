package ud5.practicas.mulleres;

public interface IActivista {
    public abstract String getCausaDefendida();
}
